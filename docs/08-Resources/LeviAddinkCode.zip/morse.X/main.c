 /*
 * MAIN Generated Driver File
 * 
 * @file main.c
 * 
 * @defgroup main MAIN
 * 
 * @brief This is the generated driver implementation file for the MAIN driver.
 *
 * @version MAIN Driver Version 1.0.2
 *
 * @version Package Version: 3.1.2
*/

/*
� [2025] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/
#include "mcc_generated_files/system/system.h"
#include "stdio.h"

/*
    Main application
*/

void MyTMR0Callback(void)
{
    //LED1_Toggle();
}

int main(void)
{
    SYSTEM_Initialize();
    ADC_Initialize();
    
    ADC_ChannelSelect(ADC_CHANNEL_ANA0);
    
    INTERRUPT_GlobalInterruptEnable();
    
    //LEDTimer_Initialize();
    UART1_Enable();
    //LEDTimer_OverflowCallbackRegister(MyTMR0Callback);
    //LEDTimer_Start();
    
    DAC1_Initialize();
    

    
    float analog_in;
    char str[20];
    int blinker;
    blinker = 0;
    while(1)
    {
        
        ADC_ConversionStart();
        while (!ADC_IsConversionDone());
        analog_in=ADC_ConversionResultGet();
        
        DAC1_SetOutput(analog_in);
        
        /*if(IO_RF4_GetValue() == 0)
        {
            IO_RD0_SetHigh();
        }
        else
        {
            IO_RD0_SetLow();
        }*/
        
        if(analog_in <= 1000)
        {
            IO_RD0_SetLow();
            IO_RA1_SetLow();
        }
        else
        {
            IO_RD0_SetHigh();
            IO_RA1_SetHigh();
        }
        
        if(IO_RD3_GetValue() == 1)
        {   
            IO_RD2_SetHigh();
        }
        else
        {
            IO_RD2_SetLow();
        }
        
        
        
        printf("Light value:");
        
        sprintf(str, "%f", analog_in); 
        printf("%s\n", str);
        
        
        blinker += 1;
        if(blinker >= 35)
        {
            IO_RD1_Toggle();
            blinker = 0;
        }
        __delay_ms(10);
       
        
    }    
}